
/**
 * Controlador para la pantalla de comparar
 */
myApp.controller('CompararController', ['$scope', '$rootScope', 
    function($scope, $rootScope) {
    
    
        
}]);