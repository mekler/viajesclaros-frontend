/**
 * Directiva para el comparador lateral
 */
myApp.directive('comparaSidebar', function ($log) { 

    function link(scope, element, attrs) {

    };

    return {
        restrict: 'A', 
        link: link
    };
}); 