myApp.constant('config', {
   restUrl: "http://localhost:8080/ViajesClaros/webresources/" 
});
