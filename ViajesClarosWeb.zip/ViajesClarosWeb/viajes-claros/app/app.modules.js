var myApp = angular.module('myApp', ['ngRoute', 'ngAnimate', 'ngResource', 'smart-table', 'ui.bootstrap', 
    'countTo', 'leaflet-directive', 'ngSanitize', 'ngCsv', 'chart.js', 'smoothScroll']);

